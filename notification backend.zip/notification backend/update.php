<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: *");


define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'mydb');

$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
$updateSeen="UPDATE notifications SET status = true where status=false" ;







$stmt = $link->prepare("SELECT email, message FROM notifications where status=false");
     
    //executing the query 
    $stmt->execute();
     
    //binding results to the query 
    $stmt->bind_result($name, $message);
     
    $data = array(); 
     
    //traversing through all the result 
    while($stmt->fetch()){
        $temp = array();
        $temp['name'] = $name; 
        $temp['message'] = $message; 
        
        array_push($data, $temp);
    }

echo json_encode($data);
     
$updated= mysqli_query($link,$updateSeen);




?>