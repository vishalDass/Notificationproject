<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: *");
	
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'mydb');

$temp=json_decode($_GET['data'],true);

$name = $temp['fname'];
$msg = $temp['message'];
$status=$temp['isSeen'];
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}


$sql = "INSERT INTO notifications (email, message, status)
VALUES ('$name', '$msg', '$status')";

$inserted=mysqli_query($link,$sql);

if($inserted){

$sql1="SELECT COUNT(status) as count
FROM notifications where status=0" ;





$notCount=mysqli_query($link,$sql1);



$notifications=mysqli_fetch_array($notCount);



echo json_encode($notifications[0]);
} 


$link->close();













?>